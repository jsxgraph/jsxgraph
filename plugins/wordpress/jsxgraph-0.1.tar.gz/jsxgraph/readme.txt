Using the JSXGraph filter makes it a lot easier to embed JSXGraph constructions into wordpress pages/posts.

Caution:
The current version has to be regarded as a pre alpha development version. Use with caution!

Installation: (by Moodle Admin)
1. Upload the complete folder "jsxgraph" into your blogs plugins folder (wp-content/plugins)
2. Navigate to the admin panel, there to your plugins and active the JSXGraph plugin
optional:
3. Remove the javascript-files in the plugins-folder in order to load the current version
   from the jsxgraph-website (same for the stylesheet).

Usage:
1. Open a a blog post or new page and
2. write your desired content. At the position the construction should appear, create a construction by:
	* switching to the code input
	* inserting a <jsxgraph>-tag with all required parameters

Be aware of the fact, that you dont't see the construction unless you leave the editor and save your document.